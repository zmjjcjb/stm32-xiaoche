#include "stm32f10x.h"                  // Device header
#include "SmartCar.h"
void Infrared_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode =GPIO_Mode_IN_FLOATING ;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4| GPIO_Pin_5| GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
}

void  Move_Init(void)
{
	 if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)==0&&
			GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4)==0&&
			GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)==0&&
			GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15)==0)
			{
				Move_Forward();                                        		//ǰ��
			}
		else if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)==1&&
			    GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4)==1&&
			    GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)==1&&
			    GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15)==1)
				{                                                       
					Car_Stop();
				}                                                            //ֹͣ
		else if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)==0&&
				GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4)==0&&
				GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)==1&&
				GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15)==1)
				{
					Clockwise_Rotation();                             		//˳ת
				}
		else if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)==0&&
				GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4)==0&&
				GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)==1&&
				GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15)==0)
				{
					Turn_Right();                                    		//��ת
				}
		else if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)==0&&
			    GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4)==0&&
			    GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)==0&&
			    GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15)==1)
				{
					Clockwise_Rotation();                                   //˳ת
				}
		else if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)==0&&
				GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4)==1&&
				GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)==0&&
				GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15)==0)
				{
					Turn_Left();                                     		//��ת
				}
		else if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)==1&&
				GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4)==1&&
				GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)==0&&
				GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15)==0)
				{
					CountClockwise_Rotation();                      		//��ת
				}
		else if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)==1&&
				GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4)==0&&
				GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)==0&&
				GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15)==0)
				{
					CountClockwise_Rotation();                              //��ת
				}  
			}
