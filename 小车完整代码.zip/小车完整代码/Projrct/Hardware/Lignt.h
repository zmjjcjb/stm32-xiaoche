#ifndef __LIGHT_H
#define __LIGHT_H

void Light_Init(void);
uint8_t Light_Get(void);

#endif
