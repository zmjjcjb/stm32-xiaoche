#include "stm32f10x.h"                  // Device header
#include "Motor.h"

void SmartCar_Init(void)
{
    Motor_Init();
}
void Move_Forward(void)                  //ǰ��
{
    LeftMotor_SetSpeed(70);
	RightMotor_SetSpeed(70);
}
void Move_Backward(void)                 //����
{
	 LeftMotor_SetSpeed(-50);
	RightMotor_SetSpeed(-50);
}
void Car_Stop(void)                      //ͣ��
{
       LeftMotor_SetSpeed(0);
	   RightMotor_SetSpeed(0);
}
void Turn_Left(void)                     //��ת
{
	LeftMotor_SetSpeed(0);
	RightMotor_SetSpeed(100);
}
void Turn_Right(void)                    //��ת
{
	LeftMotor_SetSpeed(100);
	RightMotor_SetSpeed(0);
}
void Clockwise_Rotation(void)            //˳ʱ����ת
{
	   LeftMotor_SetSpeed(50);
	RightMotor_SetSpeed(-50);
}
void CountClockwise_Rotation(void)       //��ʱ����ת
{
	LeftMotor_SetSpeed(-50);
	RightMotor_SetSpeed(50);
}
