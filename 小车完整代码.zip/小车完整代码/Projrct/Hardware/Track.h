#ifndef __INFRARED_H
#define __INFRARED_H

void Infrared_Init(void);
void  Move_Init(void);
#endif

