/* ͷ�ļ������� */
#include "stm32f10x.h"      
#include "Delay.h"
#include "OLED.h"                           //��ʾ��
#include "Motor.h"                            //���
#include "SmartCar.h"                         //�н�
#include "Serial.h"                         //����
#include "HCSR04.h"                         //������
#include "Servo.h"                            //���
#include "Track.h"                            //ѭ��

/* ���������� */
uint8_t Distance;
uint8_t Mode;
uint8_t RxData;

/* ������ */
int main(void)
{
	Serial_Init();
	SmartCar_Init();                           //��ʼ��
	OLED_Init();
	Ultrasound_Init();
	Servo_Init();
	Infrared_Init();
	OLED_ShowString(1,1,"Distance:");
	OLED_ShowString(3,1,"Speed:");	
				
	while(1)
	{   /*Distance=HCSR04_Distance();
		OLED_ShowNum(2,1,Distance,2);
		OLED_ShowNum(4,1,50,3);   */
		Move_Init();
		Mode=0;
		if(Serial_GetRxFlag() == 1)
		{
			RxData=Serial_GetRxData();
		}
		if(RxData==0x50)
		{
		    Mode++;
			if(Mode == 2)Mode =0;
		}
		if(Mode==0)
		{
			if(RxData==0x40)
			{
			Move_Forward();
			}
			if(RxData==0x41)
			{
			 Move_Backward();
			}
			if(RxData==0x42)
			{
			 Car_Stop();
			}
			if(RxData==0x43)
			{
			 Turn_Left();
			}
			if(RxData==0x44)
			{
			 Turn_Right();
			}
			if(RxData==0x45)
			{
			 Clockwise_Rotation();
			}
			if(RxData==0x46)
			{
				CountClockwise_Rotation();
			}
		
		
		}
		if(Mode==1)
		{
		     Move_Init() ;
		}
	}
}
/*{
		Move_Forward();
		uint16_t a = Test_Distance();
		Serial_SendNumber(a,3);
		if(a<15){
			Car_Stop();
			Servo_SetAngle(0);	Delay_ms(1000);
			uint16_t b= Test_Distance();
		
			Serial_SendNumber(b,3);
			if(b>15){
				Servo_SetAngle(90);
				Delay_ms(1000);
				CountClockwise_Rotation();
				Delay_ms(1000);
				Move_Forward();
			
			}
			else {
				Servo_SetAngle(180);
				Delay_ms(1000);
				uint16_t c= Test_Distance();
				Serial_SendNumber(c,3);
				if(c>15){	
					Servo_SetAngle(90);
					Delay_ms(1000);
					Turn_Right();
					Delay_ms(1000);
					Move_Forward();
				}else{
					Servo_SetAngle(90);
					while(1){};
				}
			}
		}
		Delay_ms(100);
	}
}*/
	

